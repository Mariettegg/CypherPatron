


def getPattern(word):
    index = 0
    pattern = []
    for letter in word:
        index = getPos(word ,letter)
        pattern.append(index)
    return pattern


def getPos(word ,letter):
    index = 0
    for l in word:
        if l == letter or l == letter.upper():
            return index
        else:
            index += 1

def getSimilar():
    word = input("input >> ")
    file = input("word database >> ")
    try:
        f = open(file, "r")

    except :
        print("That file does not exist")
        return 0

    words_alpha = f.readlines()


    result = []

    pattern = getPattern(word)

    for sample in words_alpha:
        sample = sample[:-1]
        if len(sample) == len(word):
            samplePattern = getPattern(sample)
            if pattern == samplePattern:
                result.append(sample)

    for x in result:
        print(x)
### MAIN ###




getSimilar()

